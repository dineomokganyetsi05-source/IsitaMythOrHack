package com.example.isitamythorhack

abstract class QUESTION {
    val text: String
    val isHACK : Boolean
}
